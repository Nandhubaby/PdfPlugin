package org.joget.pdfplugin;

import org.joget.apps.app.model.AppDefinition;
import org.joget.apps.app.service.AppUtil;
import org.joget.apps.datalist.model.DataList;
import org.joget.apps.datalist.model.DataListActionDefault;
import org.joget.apps.datalist.model.DataListActionResult;
import org.joget.apps.datalist.model.DataListCollection;
import org.joget.apps.datalist.service.DataListService;
import org.joget.apps.form.service.FormPdfUtil;
import org.joget.commons.util.LogUtil;
import org.joget.workflow.model.WorkflowAssignment;
import org.joget.workflow.util.WorkflowUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.text.DateFormat;
import java.io.File;
import java.io.IOException;
import java.io.File;
import java.nio.file.Files;
import org.joget.apps.form.service.FileUtil;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfWriter;


import org.joget.apps.datalist.model.DataList;
import org.joget.apps.datalist.model.DataListActionDefault;
import org.joget.apps.datalist.service.DataListService;
import org.joget.apps.datalist.model.DataListCollection;
import org.joget.apps.app.service.AppUtil;
import org.joget.commons.util.LogUtil;
import org.joget.apps.datalist.model.DataListActionResult;


public class downloadPDF extends DataListActionDefault {
    private final static String MESSAGE_PATH = "messages/PDFDownload";
    public String tableNames = getPropertyString("tablename");
    static String data="";
    String recordId = "13c750b5-83f5-48c6-9d00-6aac686629e5";
    //String recordId = "f73e5c99-bb6d-499a-b2a6-6fa718a99524"; //3.7
    String tableName = "img_table";
    String fileName = "ctg.png";
    String val="";
    @Override
    public String getLinkLabel() {
        String label = getPropertyString("label");
        if (label == null || label.isEmpty()) {
            label = "PDF Download";
        }
        return label;
    }

    @Override
    public String getHref() {
        return getPropertyString("href");
    }

    @Override
    public String getTarget() {
        return "post";
    }

    @Override
    public String getHrefParam() {
        return getPropertyString("hrefParam");
    }

    @Override
    public String getHrefColumn() {
        String recordIdColumn = getPropertyString("columnlabel"); //get column id from configured properties options
        if ("id".equalsIgnoreCase(recordIdColumn) || recordIdColumn.isEmpty()) {
            return getPropertyString("hrefColumn"); //Let system to set the primary key column of the binder
        } else {
            return recordIdColumn;
        }
    }

    @Override
    public String getConfirmation() {
        return null;
    }

    @Override
    public DataListActionResult executeAction(DataList dataList, String[] rowKeys) {
        DataListCollection rows = dataList.getRows();
        //LogUtil.info(String.valueOf(rows.size()),"rowsss");
        ArrayList datalistAllRowIds = new ArrayList();

        DataListService dataListService = (DataListService) AppUtil.getApplicationContext().getBean("dataListService");
        for(int index =0 ; index <rows.size(); index++) {

            String rowId = dataListService.evaluateColumnValueFromRow(rows.get(index), "id").toString();
            LogUtil.info(rowId,"row counts");
            datalistAllRowIds.add(rowId);
        }
        HttpServletRequest request = WorkflowUtil.getHttpServletRequest();
        HttpServletResponse response = WorkflowUtil.getHttpServletResponse();
        if (request != null && !"POST".equalsIgnoreCase(request.getMethod())) {
            return null;
        }

        String url = getPropertyString("redirect");
        String label = getPropertyString("columnlabel");
        String columnId = getPropertyString("columnId");
        LogUtil.info(columnId, "column values");
        String tableNames = getPropertyString("tablename");
        String listNames = getPropertyString("listname");
        String showDate = getPropertyString("displayDate");
        String getSignature = getPropertyString("signatureCol");
        int rowChecksCount = 0;

        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            con = getConnection();
            String selectedId = "";
            String rowChecks = "";
            String[] columnValues = columnId.split(",");
            String tableHeader = "";
            String tableBody = "";
            String[] colLabel = label.split(",");
            for (int k = 0; k < colLabel.length; k++) {
                String labelName = colLabel[k];
                tableHeader = tableHeader + "<th style=\"border:1px solid black;border-collapse: collapse;padding:10px;color:black;font-weight:bold;\">" + labelName + "</th>";
            }
            for (int i = 0; i < rowKeys.length; i++) {
                String id = rowKeys[i];
                selectedId += "'" + id + "'";
                if (i < rowKeys.length - 1) {
                    selectedId += ",";
                }
                String rowData = "<tr>";
                for (int j = 0; j < columnValues.length; j++) {
                    int indexOfIdValue = datalistAllRowIds.indexOf(id);
                    String columnIdVal = columnValues[j];
                    String columnValue = dataListService.evaluateColumnValueFromRow(rows.get(indexOfIdValue), columnIdVal).toString();
                    LogUtil.info(columnValue,"column values");
                    rowData += "<td style=\"border:1px solid black;border-collapse: collapse;padding:10px;color:black;\">" + columnValue + "</td>";
                }
                rowData += "</tr>";
                tableBody += rowData;
            }
            rowChecks = selectedId;
            LogUtil.info(rowChecks,"rowchecks");
            rowChecksCount = rowKeys.length;
            LogUtil.info(String.valueOf(rowChecksCount),"rowchecks");
            String fromQuery = "SELECT date_format(min(STR_TO_DATE(" + showDate + ", '%d-%m-%Y')), '%d-%m-%Y') FROM app_fd_" + tableNames + " WHERE id IN (" + rowChecks + ")";
            LogUtil.info(fromQuery,"fromquery");
            String fromDate = getDate(con, fromQuery);
            String toQuery = "SELECT date_format(max(STR_TO_DATE(" + showDate + ", '%d-%m-%Y')), '%d-%m-%Y') FROM app_fd_" + tableNames + " WHERE id IN (" + rowChecks + ")";
            LogUtil.info(toQuery,"toQuery");
            String toDate = getDate(con, toQuery);
            String dateDisplay = "<div style=\"margin-top:20px;\">"
                    + "<p style='font-weight: bold; display: inline-block;'>From Date: " + fromDate + "</p>"
                    + "<p style='font-weight: bold; display: inline-block; margin-left: 40px;'>To Date: " + toDate + "</p>"
                    + "</div><br>";
            String totalRows = "<div style='font-weight: bold;position: relative;width: 100%;'>Total Count of Registers: " + rowChecksCount + "</div><br>";
            data = "<div style=\"margin-top:20px;\">"+ dateDisplay + "<table style=\"border:1px solid #d8d8d8;border-collapse: collapse;width:100%;page-break-inside: avoid;\">" + tableHeader + tableBody + "</table>" + "<br>" + totalRows+"</div>";
            generatePdf(request, response, rowKeys[0], listNames);
        } catch (Exception e) {
            LogUtil.error(getClassName(), e, "");
        } finally {
            closeConnection(rs, pstmt, con);
        }
        return prepareResult(url, null);
    }


    @Override
    public String getName() {
        return "Download PDF Datalist ";
    }

    @Override
    public String getVersion() {
        return "1.0";
    }

    @Override
    public String getDescription() {
        return "Download PDF Datalist Action";
    }

    @Override
    public String getLabel() {
        return "Download PDF Datalist";
    }

    @Override
    public String getClassName() {
        return this.getClass().getName();
    }

    public Connection getConnection() {
        Connection con = null;
        DataSource ds = (DataSource) AppUtil.getApplicationContext().getBean("setupDataSource");
        try {
            con = ds.getConnection();
        } catch (SQLException ex) {
        }
        return con;
    }
    private String getDate(Connection con, String query) {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String dateResult = "";
        try {
            pstmt = con.prepareStatement(query);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                dateResult = rs.getString(1);
            }
        } catch (SQLException e) {
            LogUtil.error(getClassName(), e, "");
        } finally {
            closeConnection(rs, pstmt, null);
        }

        return dateResult;
    }
    protected void generatePdf(HttpServletRequest request, HttpServletResponse response, String rowKey,String pdfName) throws IOException, ServletException {
        byte[] pdf = getPdf(rowKey);
        writeResponse(request, response, pdf, pdfName + ".pdf", "application/pdf");
    }

    protected byte[] getPdf(String id) {
        String columns = getPropertyString("columnlabel");
        AppDefinition appDef = AppUtil.getCurrentAppDefinition();
        String header = null;
        if (!getPropertyString("headerHtml").isEmpty()) {
            header = getPropertyString("headerHtml");
            header = AppUtil.processHashVariable(header, null, null, null);
        }
        String footer = null;
        if (!getPropertyString("footerHtml").isEmpty()) {
            footer = getPropertyString("footerHtml");
            footer = AppUtil.processHashVariable(footer, null, null, null);
        }
        LogUtil.info("footer",footer);
        return createPdf(tableNames,header,footer, id, appDef, null, columns);
    }

    public byte[] createPdf(String table, String header,String footer,String primaryKey, AppDefinition appDef, WorkflowAssignment assignment, String ColumnName) {
        try {

            //String orientation = "<style>@page { size: landscape; }</style>";


            File profileImage = FileUtil.getFile(fileName, tableName, recordId);
            byte [] bytes = Files.readAllBytes(profileImage.toPath());
            String imgb64 = Base64.getEncoder().encodeToString(bytes);
            String src = "data:image/png;base64," + imgb64;

            String listNames = getPropertyString("listname");
            DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
            String curDate = dateFormat.format(new Date());
            String reportDate = "<div style='font-weight:bold;'>Report Date:" + curDate + "</div>";

         //   String html = orientation + "<p style=\"color:black;font-size:20px;flex: 1 0;text-align:center;font-weight:bold\">"+listNames+"<img style=\"width:100px; position: absolute;top:0; left:0;\" src=\""+src+"\" /></p>";

           String html = "<div style=\"position: relative;min-height: 70px;\">"+listNames+"<img style=\" transform: rotate(90deg); width:100px; position: absolute; left:0;\" src=\""+src+"\" /></div>";
            html =html + data + reportDate;
            header = AppUtil.processHashVariable(header, assignment, null, null);
            footer = AppUtil.processHashVariable(footer, assignment, null, null);
            //FormPdfUtil.getRenderer();
            //String css = "@page { size: A4 landscape;}";
            String css = "@page { size: 297mm 210mm;}";
            return FormPdfUtil.createPdf(html, header, footer,css, false, null, false, false);

        } catch (Exception e) {
            LogUtil.error(FormPdfUtil.class.getName(), e, "");
        }
        return null;
    }


    protected void writeResponse(HttpServletRequest request, HttpServletResponse response, byte[] bytes, String filename, String contentType) throws IOException, ServletException {
        OutputStream out = response.getOutputStream();
        try {
            String name = URLEncoder.encode(filename, "UTF8").replaceAll("\\+", "%20");
            response.setHeader("Content-Disposition", "attachment; filename=" + name + "; filename*=UTF-8''" + name);
            response.setContentType(contentType + "; charset=UTF-8");
            if (bytes.length > 0) {
                response.setContentLength(bytes.length);
                out.write(bytes);
            }
        } finally {
            out.flush();
            out.close();
            request.getRequestDispatcher(filename);
//          request.getRequestDispatcher(filename).forward(request, response);
        }
    }

    @Override
    public String getPropertyOptions() {
        return AppUtil.readPluginResource(getClassName(), "/properties/PDFDownload.json", null, true, MESSAGE_PATH);
    }

    private DataListActionResult prepareResult(String url, String errorMessage) {
        if (url != null && !url.isEmpty()) {
            DataListActionResult result = new DataListActionResult();
            result.setType(DataListActionResult.TYPE_REDIRECT);
            if (errorMessage != null) {
                result.setMessage(errorMessage);
            }
            result.setUrl(url);
            return result;
        }
        return null;
    }

    public void closeConnection(ResultSet rs, PreparedStatement pstmt, Connection con) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                LogUtil.error(getClassName(), e, "");
            }
        }
        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                LogUtil.error(getClassName(), e, "");
            }
        }
        if (con != null) {
            try {
                con.close();
            } catch (SQLException e) {
                LogUtil.error(getClassName(), e, "");
            }
        }

    }


}
